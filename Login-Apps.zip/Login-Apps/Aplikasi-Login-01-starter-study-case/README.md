# Aplikasi-Login
Sebuah aplikasi dengan fitur login.

Alur Fitur Login:
1. Memasukkan email dan password
2. Memvalidasi masukan.
3. Menampilkan halaman home.
